--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.14 (Ubuntu 12.14-0ubuntu0.20.04.1)
-- Dumped by pg_dump version 12.14 (Ubuntu 12.14-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE mdm;
--
-- Name: mdm; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE mdm WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_IN' LC_CTYPE = 'en_IN';


ALTER DATABASE mdm OWNER TO postgres;

\connect mdm

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: grievance_category; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.grievance_category AS ENUM (
    'general',
    'miscellaneous',
    'quantity',
    'quality',
    'food contamination',
    'hygiene'
);


ALTER TYPE public.grievance_category OWNER TO postgres;

--
-- Name: grievance_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.grievance_status AS ENUM (
    'resolved',
    'progressing',
    'new'
);


ALTER TYPE public.grievance_status OWNER TO postgres;

--
-- Name: menu_day; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.menu_day AS ENUM (
    'Mon',
    'Tue',
    'Wed',
    'Thu',
    'Fri',
    'Sat',
    'Sun'
);


ALTER TYPE public.menu_day OWNER TO postgres;

--
-- Name: school_category; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.school_category AS ENUM (
    'govt-aided',
    'govt',
    'private',
    'central'
);


ALTER TYPE public.school_category OWNER TO postgres;

--
-- Name: budget_check_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.budget_check_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    new_city_id integer;
    new_district_id integer;
BEGIN
    select city_id into new_city_id from school where school_id = new.school_id;
    select district_id into new_district_id from school where school_id = new.school_id;

    if (TG_OP = 'INSERT')
    THEN
        IF (new.budget+ (select total_budget from city_committee where city_id = new_city_id)
        <= (select mdm_budget from city_committee where city_id = new_city_id))
        then
            update city_committee
            set total_budget = new.budget+ total_budget
            where city_id = new_city_id;
--             return new;
        else
            raise exception 'Total Budget is not less than the budget allotted to the city';
        end if;

--         IF (new.budget+ (select total_budget from district_committee where district_id = new_district_id)
--         <= (select mdm_budget from district_committee where district_id = new_district_id))
--         then
--             update district_committee
--             set total_budget = new.budget+ total_budget
--             where district_id = new_district_id;
-- --             return new;
--         else
--             raise exception 'Total Budget is not less than the budget allotted to the district';
--         end if;

        return new;
    elsif (TG_OP = 'UPDATE')
    THEN
        IF (new.budget - old.budget + (select total_budget from city_committee where city_id = new_city_id)
        <= (select mdm_budget from city_committee where city_id = new_city_id))
        then
            update city_committee
            set total_budget = new.budget+ total_budget - old.budget
            where city_id = new_city_id;
            return new;
        else
            raise exception 'Total Budget is not less than the budget allotted to the city';
        end if;

--         IF (new.budget - old.budget + (select total_budget from district_committee where district_id = new_district_id)
--         <= (select mdm_budget from district_committee where district_id = new_district_id))
--         then
--             update district_committee
--             set total_budget = new.budget+ total_budget- old.budget
--             where district_id = new_district_id;
--  --           return new;
--         else
--             raise exception 'Total Budget is not less than the budget allotted to the district';
--         end if;

        return new;
    elsif (TG_OP = 'DELETE')
    THEN
        update city_commitee
        set total_budget = total_budget-old.budget
        where city_id = new_city_id;

--         update district_committee
--         set total_budget = total_budget-old.budget
--         where district_id = new_district_id;

    end if;
end;
$$;


ALTER FUNCTION public.budget_check_func() OWNER TO postgres;

--
-- Name: calc_extra_budget(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.calc_extra_budget(districtid integer) RETURNS TABLE(city_id integer, schools_enrolled integer, budget_alloted numeric, mdm_expenses numeric, extra_budget numeric)
    LANGUAGE plpgsql
    AS $$
begin
return query
select c.city_id, c.schools_registered, c.mdm_budget, c.total_budget, c.mdm_budget-c.total_budget as extra_budget
from city_committee c
where district_id = districtID;
end;
$$;


ALTER FUNCTION public.calc_extra_budget(districtid integer) OWNER TO postgres;

--
-- Name: change_mdm_enrollment(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.change_mdm_enrollment() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if(new.mdm_enrollment = false and new.mdm_enrollment <> old.mdm_enrollment)
    then
   	 DELETE from school
   	 where school_id = new.school_id;
    end if;
end;
$$;


ALTER FUNCTION public.change_mdm_enrollment() OWNER TO postgres;

--
-- Name: checking_item_name_stock_left_daily_trigger_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.checking_item_name_stock_left_daily_trigger_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN

	if new.item_name in (select item_name from item_prices
                    	where month = new.month and year = new.year
                        	and city_id = (select city_id from school where school_id = new.school_id) )
	then
		return new;
    else
		raise exception 'Invalid item_name/month/year in while updating stock left';
	end if;
end;
$$;


ALTER FUNCTION public.checking_item_name_stock_left_daily_trigger_func() OWNER TO postgres;

--
-- Name: checking_school_mdm_attendance_trigger_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.checking_school_mdm_attendance_trigger_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare 
	primary_s integer ;
	secondary_s integer ;
begin
	select primary_enrollment , secondary_enrollment into primary_s , secondary_s
	from mdm_school_committee where mdm_school_committee.school_id = new.school_id;
	
	if(new.mdm_primary_attendance <= primary_s and new.mdm_secondary_attendance <= secondary_s and new.date <= current_date)
	then
		return new;
	else
		raise exception 'Incorrect attendance or date insertion/updation in student attendance table';
	end if;
end;
$$;


ALTER FUNCTION public.checking_school_mdm_attendance_trigger_func() OWNER TO postgres;

--
-- Name: district_budget_check_trigger_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.district_budget_check_trigger_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
	if (TG_OP = 'INSERT')
    THEN
        IF (new.mdm_budget+ (select total_budget from district_committee where district_id = new.district_id)
        <= (select mdm_budget from district_committee where district_id = new.district_id))
        then
            update district_committee
            set total_budget = new.mdm_budget + total_budget
            where district_id = new.district_id;
        else
            raise exception 'Total Budget is not less than the budget allotted to the district';
        end if;
	elsif (TG_OP = 'UPDATE')
	then
		IF (new.mdm_budget - old.mdm_budget + (select total_budget from district_committee where district_id = new.district_id)
        <= (select mdm_budget from district_committee where district_id = new.district_id))
        then
            update district_committee
            set total_budget = new.mdm_budget+ total_budget- old.mdm_budget
            where district_id = new.district_id;
        else
            raise exception 'Total Budget is not less than the budget allotted to the district';
        end if;
	end if;

	return new;
end;
$$;


ALTER FUNCTION public.district_budget_check_trigger_func() OWNER TO postgres;

--
-- Name: district_grievances_data_func(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.district_grievances_data_func(districtid integer) RETURNS TABLE(school_id integer, complaint_number integer, date date, category public.grievance_category, complaint_details character varying, status public.grievance_status, actions_taken character varying)
    LANGUAGE plpgsql
    AS $$
begin
	return query
	select g.school_id , cast(row_number () over( partition by g.school_id order by g.date ) as integer) , g.date , g.category , g.description , g.status , g.actions_taken 
	from grievances g
	where g.school_id in (select s.school_id from school s where s.district_id = districtID) and ( g.status = 'progressing' or g.status = 'new' ) ;
end;
$$;


ALTER FUNCTION public.district_grievances_data_func(districtid integer) OWNER TO postgres;

--
-- Name: get_schools_data(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_schools_data(districtid integer, month integer, year integer) RETURNS TABLE(schoolid integer, students_registered integer, meals_served integer, monthly_expenses numeric, stock_left_expenses numeric, inspection_count integer, grievances_count integer)
    LANGUAGE plpgsql
    AS $$
declare
	school_num integer;
begin
	for school_num in (Select school_id from school where district_id = districtID)
	loop
    	return query
    	select * from school_dashboard(school_num, month, year);
	end loop;
end;
$$;


ALTER FUNCTION public.get_schools_data(districtid integer, month integer, year integer) OWNER TO postgres;

--
-- Name: school_dashboard(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.school_dashboard(schoolid_num integer, monthnum integer, yearnum integer) RETURNS TABLE(schoolid integer, students_registered integer, meals_served integer, monthly_expenses numeric, stock_left_expense numeric, inspection_count integer, grievances_count integer)
    LANGUAGE plpgsql
    AS $$
begin
return query
select m.school_id, m.primary_enrollment+ m.secondary_enrollment as students_enrolled, t1.total_enrolled, t2.total_cook_salary+ t2.food_used_expense as monthly_expenses, t2.stock_left_expense as stock_left_expense , t3.coalesce as inspection_count, t4.coalesce as grivances_count
from mdm_school_committee m,
(
	select a.school_id, cast(sum(a.mdm_primary_attendance + a.mdm_secondary_attendance) as integer) total_enrolled
	from student_attendance a
	where (extract (month from a.date) = monthNum) and extract (year from date) = yearNum
	group by school_id
	having a.school_id = schoolID_num 
) as t1,
(
	select * from school_monthly_expenses_func(schoolID_num, monthNum,yearNum )
) as t2,
(   
	select cast( coalesce ((select count(date) 
	from inspection_feedback
	group by school_id , inspection_feedback.date 
	having school_id = schoolID_num and extract (month from inspection_feedback.date) = monthNum and extract (year from inspection_feedback.date) = yearNum) , 0) as integer) 
) as t3,
(
	select cast ( coalesce( (select count(complaint_id)
	from grievances
	group by school_id , grievances.date
	having school_id = schoolID_num and extract (month from grievances.date) = monthNum and extract (year from grievances.date) = yearNum ) , 0) as integer)
) as t4
where m.school_id = schoolID_num;
end;
$$;


ALTER FUNCTION public.school_dashboard(schoolid_num integer, monthnum integer, yearnum integer) OWNER TO postgres;

--
-- Name: school_mdm_registration_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.school_mdm_registration_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
   if(TG_OP = 'INSERT' and new.mdm_enrollment = true)
   then
       update district_committee
       set schools_registered = schools_registered+1
       where district_committee.district_id = new.district_id;


       update city_committee
       set schools_registered = schools_registered+1
       where city_committee.city_id = new.city_id;

-- 		return new;
   elsif(TG_OP = 'UPDATE' and new.mdm_enrollment <> old.mdm_enrollment and new.mdm_enrollment = true)
   then
      
       update district_committee
       set schools_registered = schools_registered+1
       where district_committee.district_id = new.district_id;


       update city_committee
       set schools_registered = schools_registered+1
       where city_committee.city_id = new.city_id;
	   
-- 	   return new;
   elsif(TG_OP = 'DELETE' and old.mdm_enrollment = true)
   then
       update district_committee
       set schools_registered = schools_registered-1
       where district_committee.district_id = old.district_id;


       update city_committee
       set schools_registered = schools_registered-1
       where city_committee.city_id = old.city_id;		
   end if;
   return new;
end
$$;


ALTER FUNCTION public.school_mdm_registration_func() OWNER TO postgres;

--
-- Name: school_monthly_expenses_func(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.school_monthly_expenses_func(schoolid integer, month integer, year integer) RETURNS TABLE(total_cook_salary numeric, food_used_expense numeric, stock_left_expense numeric)
    LANGUAGE plpgsql
    AS $$
begin
	return query 
	select salary_table.c_salary , expenses_table.fe , expenses_table.sle
	from 
		( select  sum(c.salary) as c_salary
		  from cook c
		  group by c.school_id 
		  having c.school_id = schoolID) as salary_table ,
	 
	    ( select sum(t2.item_expense) as fe , sum(t2.stock_expense) as sle
		  from (select * from school_monthly_item_expenses_func(schoolID , month , year)) as t2 )  as expenses_table ;
end;
$$;


ALTER FUNCTION public.school_monthly_expenses_func(schoolid integer, month integer, year integer) OWNER TO postgres;

--
-- Name: school_monthly_item_expenses_func(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.school_monthly_item_expenses_func(schoolid integer, monthnum integer, yearnum integer) RETURNS TABLE(item_name character varying, item_expense numeric, stock_expense numeric)
    LANGUAGE plpgsql
    AS $$
begin
	return query 
	select t1.item_name as item_name , t1.quantity * i.price  as item_expense , s.item_quantity * i.price as stock_expense
	from  item_prices i , stock_left s ,
		  ( select d.item_name , sum(d.item_quantity) as quantity
			from daily_stock_usage d
		    where  d.school_id = schoolID and extract(MONTH from d.date) = monthNum and extract(YEAR FROM d.date) = yearNum
			group by d.item_name ) as t1 
	where t1.item_name = i.item_name and t1.item_name = s.item_name and s.school_id = schoolID and
		  i.city_id = (select city_id from school where school_id = schoolID) and
		  s.month = monthNum and s.year = yearNum and i.month = monthNum and i.year = yearNum ;
end;
$$;


ALTER FUNCTION public.school_monthly_item_expenses_func(schoolid integer, monthnum integer, yearnum integer) OWNER TO postgres;

--
-- Name: update_school_strength_trigger_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_school_strength_trigger_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
	if(TG_OP = 'INSERT')
	then
		if(new.mdm_enrollment = true)
		then
			if(new.standard <= 5)
			then
				update mdm_school_committee
				set primary_enrollment = primary_enrollment + 1
				where mdm_school_committee.school_id = new.school_id;
			else 
				update mdm_school_committee
				set secondary_enrollment = secondary_enrollment+1
				where mdm_school_committee.school_id = new.school_id;
			end if;
		end if;

		if(new.standard <= 5)
		then
		
			update school
			set primary_strength = primary_strength + 1
			where school.school_id = new.school_id;
		else 
			update school
			set secondary_strength = secondary_strength+1
			where school.school_id = new.school_id;
		end if;
		
-- 		return new ;
	elsif (TG_OP = 'UPDATE')
	then
	
		if(new.mdm_enrollment != old.mdm_enrollment and new.mdm_enrollment = true)
		then
			if(new.standard <= 5)
			then
				update mdm_school_committee
				set primary_enrollment = primary_enrollment + 1
				where mdm_school_committee.school_id = new.school_id;
			else 
				update mdm_school_committee
				set secondary_enrollment = secondary_enrollment+1
				where mdm_school_committee.school_id = new.school_id;
			end if;
		elsif (new.mdm_enrollment != old.mdm_enrollment and new.mdm_enrollment = false)
		then
			if(new.standard <= 5)
			then
			
				update mdm_school_committee
				set primary_enrollment = primary_enrollment - 1
				where mdm_school_committee.school_id = new.school_id;
			else 
				update mdm_school_committee
				set secondary_enrollment = secondary_enrollment - 1
				where mdm_school_committee.school_id = new.school_id;
			end if;
		end if;
		
-- 		return new ;
	elsif (TG_OP = 'DELETE')
	then
		if(old.mdm_enrollment = true)
		then
			if(old.standard <= 5)
			then
				update mdm_school_committee
				set primary_enrollment = primary_enrollment - 1
				where mdm_school_committee.school_id = new.school_id;
			else 
				update mdm_school_committee
				set secondary_enrollment = secondary_enrollment - 1
				where mdm_school_committee.school_id = new.school_id;
			end if;
		end if;

		if(new.standard <= 5)
		then
			update school
			set primary_strength = primary_strength - 1
			where school.school_id = new.school_id;
		else 
			update school
			set secondary_strength = secondary_strength - 1
			where school.school_id = new.school_id;
		end if;
	end if;
	return new;
end;
$$;


ALTER FUNCTION public.update_school_strength_trigger_func() OWNER TO postgres;

--
-- Name: update_stock_left_daily(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_stock_left_daily() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN

	if new.item_name in (select item_name from item_prices
                    	where month = (select extract(MONTH from new.date)) and year = (select EXTRACT(YEAR from new.date))
                        	and city_id = (select city_id from school where school_id = new.school_id) )
	then
    	IF (TG_OP = 'INSERT')
    	THEN
        	update stock_left
        	set item_quantity = item_quantity- new.item_quantity
        	where item_name = new.item_name and  month = (select extract(MONTH from new.date)) and year = (select EXTRACT(YEAR from new.date)) and school_id = new.school_id;
    	ELSIF (TG_OP = 'UPDATE')
    	THEN
        	if(old.item_quantity <> new.item_quantity)
        	then
            	update stock_left
            	set item_quantity = item_quantity +old.item_quantity -new.item_quantity
            	where item_name = new.item_name and month = (select extract(MONTH from new.date)) and year = (select EXTRACT(YEAR from new.date)) and school_id = new.school_id;
        	END IF;
    	END IF;
	ELSE
    	raise exception 'Invalid Item Name';
	END IF;
	return new;
END;
$$;


ALTER FUNCTION public.update_stock_left_daily() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: student; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student (
    student_id integer NOT NULL,
    school_id integer NOT NULL,
    student_name character varying NOT NULL,
    standard integer,
    height numeric,
    weight numeric,
    mdm_enrollment boolean,
    CONSTRAINT student_standard_check CHECK (((standard >= 1) AND (standard <= 12)))
);


ALTER TABLE public.student OWNER TO postgres;

--
-- Name: bmi_calculation; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.bmi_calculation AS
 SELECT student.student_id,
    student.student_name,
    (((student.weight * (100)::numeric) * (100)::numeric) / (student.height * student.height)) AS bmi,
        CASE
            WHEN ((((student.weight * (100)::numeric) * (100)::numeric) / (student.height * student.height)) < 18.5) THEN 'underweight'::text
            WHEN (((((student.weight * (100)::numeric) * (100)::numeric) / (student.height * student.height)) >= 18.5) AND ((((student.weight * (100)::numeric) * (100)::numeric) / (student.height * student.height)) <= 24.9)) THEN 'healthy-weight'::text
            WHEN (((((student.weight * (100)::numeric) * (100)::numeric) / (student.height * student.height)) > 24.9) AND ((((student.weight * (100)::numeric) * (100)::numeric) / (student.height * student.height)) <= 29.9)) THEN 'overweight'::text
            WHEN ((((student.weight * (100)::numeric) * (100)::numeric) / (student.height * student.height)) > 29.9) THEN 'obese'::text
            ELSE NULL::text
        END AS category
   FROM public.student;


ALTER TABLE public.bmi_calculation OWNER TO postgres;

--
-- Name: city_committee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.city_committee (
    city_id integer NOT NULL,
    district_id integer,
    city_name character varying NOT NULL,
    officer_id integer,
    officer_name character varying,
    schools_registered integer,
    mdm_budget numeric,
    total_budget numeric,
    CONSTRAINT city_committee_mdm_budget_check CHECK ((mdm_budget >= (0)::numeric)),
    CONSTRAINT city_committee_total_budget_check CHECK ((total_budget >= (0)::numeric))
);


ALTER TABLE public.city_committee OWNER TO postgres;

--
-- Name: grievances; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.grievances (
    complaint_id integer NOT NULL,
    school_id integer NOT NULL,
    category public.grievance_category NOT NULL,
    description character varying,
    status public.grievance_status NOT NULL,
    date date,
    actions_taken character varying,
    CONSTRAINT date_check_constraint_greivances CHECK ((date <= CURRENT_DATE))
);


ALTER TABLE public.grievances OWNER TO postgres;

--
-- Name: mdm_school_committee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mdm_school_committee (
    school_id integer NOT NULL,
    manager_id integer,
    manager_name character varying,
    budget numeric NOT NULL,
    primary_enrollment integer NOT NULL,
    secondary_enrollment integer NOT NULL,
    CONSTRAINT mdm_school_committee_budget_check CHECK ((budget >= (0)::numeric)),
    CONSTRAINT mdm_school_committee_primary_enrollment_check CHECK ((primary_enrollment >= 0)),
    CONSTRAINT mdm_school_committee_secondary_enrollment_check CHECK ((secondary_enrollment >= 0))
);


ALTER TABLE public.mdm_school_committee OWNER TO postgres;

--
-- Name: city_officer_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.city_officer_view AS
 SELECT mdm_school_committee.school_id,
    mdm_school_committee.manager_id,
    mdm_school_committee.manager_name,
    mdm_school_committee.budget,
    (mdm_school_committee.primary_enrollment + mdm_school_committee.secondary_enrollment) AS students_enrolled,
    t1."coalesce" AS grievances_registered
   FROM public.mdm_school_committee,
    ( SELECT COALESCE(( SELECT count(grievances.complaint_id) AS count
                   FROM public.grievances), (0)::bigint) AS "coalesce") t1;


ALTER TABLE public.city_officer_view OWNER TO postgres;

--
-- Name: cook; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cook (
    cook_id integer NOT NULL,
    cook_name character varying,
    salary numeric,
    school_id integer,
    CONSTRAINT cook_salary_check CHECK ((salary > (0)::numeric))
);


ALTER TABLE public.cook OWNER TO postgres;

--
-- Name: daily_stock_usage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.daily_stock_usage (
    school_id integer NOT NULL,
    item_name character varying NOT NULL,
    item_quantity numeric,
    date date NOT NULL,
    CONSTRAINT daily_stock_usage_item_quantity_check CHECK ((item_quantity >= (0)::numeric))
);


ALTER TABLE public.daily_stock_usage OWNER TO postgres;

--
-- Name: district_committee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.district_committee (
    district_id integer NOT NULL,
    district_name character varying,
    officer_id integer,
    officer_name character varying,
    schools_registered integer,
    mdm_budget numeric,
    total_budget numeric,
    CONSTRAINT district_committee_mdm_budget_check CHECK ((mdm_budget > (0)::numeric)),
    CONSTRAINT district_committee_total_budget_check CHECK ((total_budget >= (0)::numeric))
);


ALTER TABLE public.district_committee OWNER TO postgres;

--
-- Name: district_static; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.district_static (
    district_id integer NOT NULL,
    day public.menu_day NOT NULL,
    items text[]
);


ALTER TABLE public.district_static OWNER TO postgres;

--
-- Name: inspection_feedback; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inspection_feedback (
    date date NOT NULL,
    school_id integer NOT NULL,
    feedback character varying,
    CONSTRAINT date_check_constraint CHECK ((date <= CURRENT_DATE))
);


ALTER TABLE public.inspection_feedback OWNER TO postgres;

--
-- Name: item_prices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item_prices (
    item_name character varying NOT NULL,
    price numeric NOT NULL,
    month integer NOT NULL,
    year integer NOT NULL,
    city_id integer NOT NULL,
    CONSTRAINT item_prices_month_check CHECK (((month >= 1) AND (month <= 12))),
    CONSTRAINT item_prices_price_check CHECK ((price > (0)::numeric))
);


ALTER TABLE public.item_prices OWNER TO postgres;

--
-- Name: school; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.school (
    school_id integer NOT NULL,
    school_name character varying,
    principal_name character varying,
    contact_number character varying,
    email character varying,
    school_type public.school_category,
    city_id integer,
    district_id integer,
    primary_strength integer,
    secondary_strength integer,
    mdm_enrollment boolean,
    CONSTRAINT contact_number_constraint_school CHECK (((contact_number)::text ~ similar_escape('[1-9]{1}[0-9]{9}'::text, NULL::text))),
    CONSTRAINT email_constraint_school CHECK (((email)::text ~ similar_escape('[a-zA-Z_]+[.](org)[.](in)'::text, NULL::text))),
    CONSTRAINT school_primary_strength_check CHECK ((primary_strength >= 0)),
    CONSTRAINT school_secondary_strength_check CHECK ((secondary_strength >= 0))
);


ALTER TABLE public.school OWNER TO postgres;

--
-- Name: school_attendance; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.school_attendance AS
SELECT
    NULL::integer AS school_id,
    NULL::character varying AS school_name,
    NULL::numeric AS primary_attendance_percentage,
    NULL::numeric AS secondary_attendance_percentage;


ALTER TABLE public.school_attendance OWNER TO postgres;

--
-- Name: stock_left; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_left (
    school_id integer NOT NULL,
    item_name character varying NOT NULL,
    item_quantity numeric NOT NULL,
    month integer NOT NULL,
    year integer NOT NULL,
    CONSTRAINT stock_left_item_quantity_check CHECK ((item_quantity >= (0)::numeric))
);


ALTER TABLE public.stock_left OWNER TO postgres;

--
-- Name: student_attendance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_attendance (
    school_id integer NOT NULL,
    date date NOT NULL,
    mdm_secondary_attendance integer,
    mdm_primary_attendance integer
);


ALTER TABLE public.student_attendance OWNER TO postgres;

--
-- Data for Name: city_committee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.city_committee (city_id, district_id, city_name, officer_id, officer_name, schools_registered, mdm_budget, total_budget) FROM stdin;
\.
COPY public.city_committee (city_id, district_id, city_name, officer_id, officer_name, schools_registered, mdm_budget, total_budget) FROM '$$PATH$$/3174.dat';

--
-- Data for Name: cook; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cook (cook_id, cook_name, salary, school_id) FROM stdin;
\.
COPY public.cook (cook_id, cook_name, salary, school_id) FROM '$$PATH$$/3177.dat';

--
-- Data for Name: daily_stock_usage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.daily_stock_usage (school_id, item_name, item_quantity, date) FROM stdin;
\.
COPY public.daily_stock_usage (school_id, item_name, item_quantity, date) FROM '$$PATH$$/3183.dat';

--
-- Data for Name: district_committee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.district_committee (district_id, district_name, officer_id, officer_name, schools_registered, mdm_budget, total_budget) FROM stdin;
\.
COPY public.district_committee (district_id, district_name, officer_id, officer_name, schools_registered, mdm_budget, total_budget) FROM '$$PATH$$/3173.dat';

--
-- Data for Name: district_static; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.district_static (district_id, day, items) FROM stdin;
\.
COPY public.district_static (district_id, day, items) FROM '$$PATH$$/3182.dat';

--
-- Data for Name: grievances; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.grievances (complaint_id, school_id, category, description, status, date, actions_taken) FROM stdin;
\.
COPY public.grievances (complaint_id, school_id, category, description, status, date, actions_taken) FROM '$$PATH$$/3180.dat';

--
-- Data for Name: inspection_feedback; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inspection_feedback (date, school_id, feedback) FROM stdin;
\.
COPY public.inspection_feedback (date, school_id, feedback) FROM '$$PATH$$/3178.dat';

--
-- Data for Name: item_prices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item_prices (item_name, price, month, year, city_id) FROM stdin;
\.
COPY public.item_prices (item_name, price, month, year, city_id) FROM '$$PATH$$/3179.dat';

--
-- Data for Name: mdm_school_committee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mdm_school_committee (school_id, manager_id, manager_name, budget, primary_enrollment, secondary_enrollment) FROM stdin;
\.
COPY public.mdm_school_committee (school_id, manager_id, manager_name, budget, primary_enrollment, secondary_enrollment) FROM '$$PATH$$/3181.dat';

--
-- Data for Name: school; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.school (school_id, school_name, principal_name, contact_number, email, school_type, city_id, district_id, primary_strength, secondary_strength, mdm_enrollment) FROM stdin;
\.
COPY public.school (school_id, school_name, principal_name, contact_number, email, school_type, city_id, district_id, primary_strength, secondary_strength, mdm_enrollment) FROM '$$PATH$$/3175.dat';

--
-- Data for Name: stock_left; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_left (school_id, item_name, item_quantity, month, year) FROM stdin;
\.
COPY public.stock_left (school_id, item_name, item_quantity, month, year) FROM '$$PATH$$/3184.dat';

--
-- Data for Name: student; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student (student_id, school_id, student_name, standard, height, weight, mdm_enrollment) FROM stdin;
\.
COPY public.student (student_id, school_id, student_name, standard, height, weight, mdm_enrollment) FROM '$$PATH$$/3185.dat';

--
-- Data for Name: student_attendance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_attendance (school_id, date, mdm_secondary_attendance, mdm_primary_attendance) FROM stdin;
\.
COPY public.student_attendance (school_id, date, mdm_secondary_attendance, mdm_primary_attendance) FROM '$$PATH$$/3176.dat';

--
-- Name: city_committee city_committee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.city_committee
    ADD CONSTRAINT city_committee_pkey PRIMARY KEY (city_id);


--
-- Name: cook cook_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cook
    ADD CONSTRAINT cook_pkey PRIMARY KEY (cook_id);


--
-- Name: daily_stock_usage daily_stock_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_stock_usage
    ADD CONSTRAINT daily_stock_usage_pkey PRIMARY KEY (school_id, item_name, date);


--
-- Name: district_committee district_committee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.district_committee
    ADD CONSTRAINT district_committee_pkey PRIMARY KEY (district_id);


--
-- Name: district_static district_static_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.district_static
    ADD CONSTRAINT district_static_pkey PRIMARY KEY (district_id, day);


--
-- Name: grievances grievances_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grievances
    ADD CONSTRAINT grievances_pkey PRIMARY KEY (complaint_id, school_id);


--
-- Name: inspection_feedback inspection_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_feedback
    ADD CONSTRAINT inspection_feedback_pkey PRIMARY KEY (date, school_id);


--
-- Name: item_prices item_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_prices
    ADD CONSTRAINT item_prices_pkey PRIMARY KEY (item_name, month, year, city_id);


--
-- Name: mdm_school_committee mdm_school_committee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mdm_school_committee
    ADD CONSTRAINT mdm_school_committee_pkey PRIMARY KEY (school_id);


--
-- Name: school school_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.school
    ADD CONSTRAINT school_pkey PRIMARY KEY (school_id);


--
-- Name: stock_left stock_left_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_left
    ADD CONSTRAINT stock_left_pkey PRIMARY KEY (school_id, item_name, month, year);


--
-- Name: student_attendance student_attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_attendance
    ADD CONSTRAINT student_attendance_pkey PRIMARY KEY (school_id, date);


--
-- Name: student student_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT student_pkey PRIMARY KEY (student_id, school_id);


--
-- Name: school_attendance _RETURN; Type: RULE; Schema: public; Owner: postgres
--

CREATE OR REPLACE VIEW public.school_attendance AS
 SELECT t1.school_id,
    t1.school_name,
    (t1.primary_percent * (100)::numeric) AS primary_attendance_percentage,
    (t1.secondary_percent * (100)::numeric) AS secondary_attendance_percentage
   FROM ( SELECT s.school_id,
            s.school_name,
            ((sum(a.mdm_primary_attendance))::numeric / (sum(s.primary_strength))::numeric) AS primary_percent,
            ((sum(a.mdm_secondary_attendance))::numeric / (sum(s.secondary_strength))::numeric) AS secondary_percent
           FROM public.student_attendance a,
            public.school s
          WHERE ((date_part('month'::text, a.date) = date_part('month'::text, CURRENT_DATE)) AND (date_part('year'::text, a.date) = date_part('year'::text, CURRENT_DATE)))
          GROUP BY s.school_id, a.school_id
         HAVING (s.school_id = a.school_id)) t1
  ORDER BY t1.school_id;


--
-- Name: mdm_school_committee budget_check_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER budget_check_trigger BEFORE INSERT OR DELETE OR UPDATE ON public.mdm_school_committee FOR EACH ROW EXECUTE FUNCTION public.budget_check_func();


--
-- Name: stock_left checking_item_name_stock_left_daily_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER checking_item_name_stock_left_daily_trigger BEFORE INSERT OR UPDATE ON public.stock_left FOR EACH ROW EXECUTE FUNCTION public.checking_item_name_stock_left_daily_trigger_func();


--
-- Name: student_attendance checking_school_mdm_attendance_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER checking_school_mdm_attendance_trigger BEFORE INSERT OR UPDATE ON public.student_attendance FOR EACH ROW EXECUTE FUNCTION public.checking_school_mdm_attendance_trigger_func();


--
-- Name: school deregister_school; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER deregister_school AFTER UPDATE OF mdm_enrollment ON public.school FOR EACH ROW EXECUTE FUNCTION public.change_mdm_enrollment();


--
-- Name: city_committee district_budget_check_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER district_budget_check_trigger BEFORE INSERT OR UPDATE ON public.city_committee FOR EACH ROW EXECUTE FUNCTION public.district_budget_check_trigger_func();


--
-- Name: school school_mdm_registration_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER school_mdm_registration_trigger AFTER INSERT OR DELETE OR UPDATE ON public.school FOR EACH ROW EXECUTE FUNCTION public.school_mdm_registration_func();


--
-- Name: student update_school_strength_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_school_strength_trigger AFTER INSERT OR DELETE OR UPDATE ON public.student FOR EACH ROW EXECUTE FUNCTION public.update_school_strength_trigger_func();


--
-- Name: daily_stock_usage update_stock_left_daily_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_stock_left_daily_trigger BEFORE INSERT OR UPDATE ON public.daily_stock_usage FOR EACH ROW EXECUTE FUNCTION public.update_stock_left_daily();


--
-- Name: city_committee fk_city_committee_district_committee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.city_committee
    ADD CONSTRAINT fk_city_committee_district_committee FOREIGN KEY (district_id) REFERENCES public.district_committee(district_id);


--
-- Name: cook fk_cook_school; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cook
    ADD CONSTRAINT fk_cook_school FOREIGN KEY (school_id) REFERENCES public.school(school_id) ON DELETE CASCADE;


--
-- Name: daily_stock_usage fk_daily_stock_usage_school; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_stock_usage
    ADD CONSTRAINT fk_daily_stock_usage_school FOREIGN KEY (school_id) REFERENCES public.school(school_id) ON DELETE CASCADE;


--
-- Name: district_static fk_district_static_district_committee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.district_static
    ADD CONSTRAINT fk_district_static_district_committee FOREIGN KEY (district_id) REFERENCES public.district_committee(district_id);


--
-- Name: grievances fk_grievances_school; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grievances
    ADD CONSTRAINT fk_grievances_school FOREIGN KEY (school_id) REFERENCES public.school(school_id) ON DELETE CASCADE;


--
-- Name: inspection_feedback fk_inspection_feedback_school; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_feedback
    ADD CONSTRAINT fk_inspection_feedback_school FOREIGN KEY (school_id) REFERENCES public.school(school_id) ON DELETE CASCADE;


--
-- Name: item_prices fk_item_prices_city_committee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_prices
    ADD CONSTRAINT fk_item_prices_city_committee FOREIGN KEY (city_id) REFERENCES public.city_committee(city_id);


--
-- Name: mdm_school_committee fk_mdm_committee_school; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mdm_school_committee
    ADD CONSTRAINT fk_mdm_committee_school FOREIGN KEY (school_id) REFERENCES public.school(school_id) ON DELETE CASCADE;


--
-- Name: school fk_school_city_committee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.school
    ADD CONSTRAINT fk_school_city_committee FOREIGN KEY (city_id) REFERENCES public.city_committee(city_id);


--
-- Name: school fk_school_district_committee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.school
    ADD CONSTRAINT fk_school_district_committee FOREIGN KEY (district_id) REFERENCES public.district_committee(district_id);


--
-- Name: stock_left fk_stock_left_school; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_left
    ADD CONSTRAINT fk_stock_left_school FOREIGN KEY (school_id) REFERENCES public.school(school_id) ON DELETE CASCADE;


--
-- Name: student_attendance fk_student_attendance_school; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_attendance
    ADD CONSTRAINT fk_student_attendance_school FOREIGN KEY (school_id) REFERENCES public.school(school_id) ON DELETE CASCADE;


--
-- Name: student fk_student_school; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT fk_student_school FOREIGN KEY (school_id) REFERENCES public.school(school_id) ON DELETE CASCADE;


--
-- Name: city_committee; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.city_committee ENABLE ROW LEVEL SECURITY;

--
-- Name: city_committee city_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY city_role_policy1 ON public.city_committee TO city_role USING ((city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer)) WITH CHECK ((city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer));


--
-- Name: cook city_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY city_role_policy1 ON public.cook TO city_role USING ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer)))) WITH CHECK ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer))));


--
-- Name: daily_stock_usage city_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY city_role_policy1 ON public.daily_stock_usage TO city_role USING ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer)))) WITH CHECK ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer))));


--
-- Name: district_committee city_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY city_role_policy1 ON public.district_committee TO city_role USING ((district_id = ( SELECT city_committee.district_id
   FROM public.city_committee
  WHERE (city_committee.city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer)))) WITH CHECK ((district_id = ( SELECT city_committee.district_id
   FROM public.city_committee
  WHERE (city_committee.city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer))));


--
-- Name: district_static city_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY city_role_policy1 ON public.district_static TO city_role USING ((district_id = ( SELECT city_committee.district_id
   FROM public.city_committee
  WHERE (city_committee.city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer)))) WITH CHECK ((district_id = ( SELECT city_committee.district_id
   FROM public.city_committee
  WHERE (city_committee.city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer))));


--
-- Name: grievances city_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY city_role_policy1 ON public.grievances TO city_role USING ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer)))) WITH CHECK ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer))));


--
-- Name: inspection_feedback city_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY city_role_policy1 ON public.inspection_feedback TO city_role USING ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer)))) WITH CHECK ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer))));


--
-- Name: item_prices city_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY city_role_policy1 ON public.item_prices TO city_role USING ((city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer)) WITH CHECK ((city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer));


--
-- Name: mdm_school_committee city_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY city_role_policy1 ON public.mdm_school_committee TO city_role USING ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer)))) WITH CHECK ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer))));


--
-- Name: school city_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY city_role_policy1 ON public.school TO city_role USING ((city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer)) WITH CHECK ((city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer));


--
-- Name: stock_left city_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY city_role_policy1 ON public.stock_left TO city_role USING ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer)))) WITH CHECK ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer))));


--
-- Name: student city_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY city_role_policy1 ON public.student TO city_role USING ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer)))) WITH CHECK ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer))));


--
-- Name: student_attendance city_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY city_role_policy1 ON public.student_attendance TO city_role USING ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer)))) WITH CHECK ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.city_id = (ltrim((CURRENT_USER)::text, 'city_officer'::text))::integer))));


--
-- Name: cook; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.cook ENABLE ROW LEVEL SECURITY;

--
-- Name: daily_stock_usage; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.daily_stock_usage ENABLE ROW LEVEL SECURITY;

--
-- Name: district_committee; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.district_committee ENABLE ROW LEVEL SECURITY;

--
-- Name: city_committee district_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY district_role_policy1 ON public.city_committee TO district_role USING ((district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer)) WITH CHECK ((district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer));


--
-- Name: cook district_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY district_role_policy1 ON public.cook TO district_role USING ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer)))) WITH CHECK ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer))));


--
-- Name: daily_stock_usage district_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY district_role_policy1 ON public.daily_stock_usage TO district_role USING ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer)))) WITH CHECK ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer))));


--
-- Name: district_committee district_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY district_role_policy1 ON public.district_committee TO district_role USING ((district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer)) WITH CHECK ((district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer));


--
-- Name: district_static district_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY district_role_policy1 ON public.district_static TO district_role USING ((district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer)) WITH CHECK ((district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer));


--
-- Name: grievances district_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY district_role_policy1 ON public.grievances TO district_role USING ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer)))) WITH CHECK ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer))));


--
-- Name: inspection_feedback district_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY district_role_policy1 ON public.inspection_feedback TO district_role USING ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer)))) WITH CHECK ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer))));


--
-- Name: item_prices district_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY district_role_policy1 ON public.item_prices TO district_role USING ((city_id IN ( SELECT city_committee.city_id
   FROM public.city_committee
  WHERE (city_committee.district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer)))) WITH CHECK ((city_id IN ( SELECT city_committee.city_id
   FROM public.city_committee
  WHERE (city_committee.district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer))));


--
-- Name: mdm_school_committee district_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY district_role_policy1 ON public.mdm_school_committee TO district_role USING ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer)))) WITH CHECK ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer))));


--
-- Name: school district_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY district_role_policy1 ON public.school TO district_role USING ((district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer)) WITH CHECK ((district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer));


--
-- Name: stock_left district_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY district_role_policy1 ON public.stock_left TO district_role USING ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer)))) WITH CHECK ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer))));


--
-- Name: student district_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY district_role_policy1 ON public.student TO district_role USING ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer)))) WITH CHECK ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer))));


--
-- Name: student_attendance district_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY district_role_policy1 ON public.student_attendance TO district_role USING ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer)))) WITH CHECK ((school_id IN ( SELECT school.school_id
   FROM public.school
  WHERE (school.district_id = (ltrim((CURRENT_USER)::text, 'district_officer'::text))::integer))));


--
-- Name: district_static; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.district_static ENABLE ROW LEVEL SECURITY;

--
-- Name: grievances; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.grievances ENABLE ROW LEVEL SECURITY;

--
-- Name: inspection_feedback; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.inspection_feedback ENABLE ROW LEVEL SECURITY;

--
-- Name: item_prices; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.item_prices ENABLE ROW LEVEL SECURITY;

--
-- Name: mdm_school_committee; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.mdm_school_committee ENABLE ROW LEVEL SECURITY;

--
-- Name: school; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.school ENABLE ROW LEVEL SECURITY;

--
-- Name: city_committee school_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY school_role_policy1 ON public.city_committee TO school_role USING ((city_id = ( SELECT school.city_id
   FROM public.school
  WHERE (school.school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer)))) WITH CHECK ((city_id = ( SELECT school.city_id
   FROM public.school
  WHERE (school.school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer))));


--
-- Name: cook school_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY school_role_policy1 ON public.cook TO school_role USING ((school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer)) WITH CHECK ((school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer));


--
-- Name: daily_stock_usage school_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY school_role_policy1 ON public.daily_stock_usage TO school_role USING ((school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer)) WITH CHECK ((school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer));


--
-- Name: district_committee school_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY school_role_policy1 ON public.district_committee TO school_role USING ((district_id = ( SELECT school.district_id
   FROM public.school
  WHERE (school.school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer)))) WITH CHECK ((district_id = ( SELECT school.district_id
   FROM public.school
  WHERE (school.school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer))));


--
-- Name: district_static school_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY school_role_policy1 ON public.district_static TO school_role USING ((district_id = ( SELECT school.district_id
   FROM public.school
  WHERE (school.school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer)))) WITH CHECK ((district_id = ( SELECT school.district_id
   FROM public.school
  WHERE (school.school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer))));


--
-- Name: grievances school_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY school_role_policy1 ON public.grievances TO school_role USING ((school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer)) WITH CHECK ((school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer));


--
-- Name: inspection_feedback school_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY school_role_policy1 ON public.inspection_feedback TO school_role USING ((school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer)) WITH CHECK ((school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer));


--
-- Name: item_prices school_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY school_role_policy1 ON public.item_prices TO school_role USING ((city_id = ( SELECT school.city_id
   FROM public.school
  WHERE (school.school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer)))) WITH CHECK ((city_id = ( SELECT school.city_id
   FROM public.school
  WHERE (school.school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer))));


--
-- Name: mdm_school_committee school_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY school_role_policy1 ON public.mdm_school_committee TO school_role USING ((school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer));


--
-- Name: school school_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY school_role_policy1 ON public.school TO school_role USING ((school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer)) WITH CHECK ((school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer));


--
-- Name: stock_left school_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY school_role_policy1 ON public.stock_left TO school_role USING ((school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer)) WITH CHECK ((school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer));


--
-- Name: student school_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY school_role_policy1 ON public.student TO school_role USING ((school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer)) WITH CHECK ((school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer));


--
-- Name: student_attendance school_role_policy1; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY school_role_policy1 ON public.student_attendance TO school_role USING ((school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer)) WITH CHECK ((school_id = (ltrim((CURRENT_USER)::text, 'school_manager'::text))::integer));


--
-- Name: stock_left; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.stock_left ENABLE ROW LEVEL SECURITY;

--
-- Name: student; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.student ENABLE ROW LEVEL SECURITY;

--
-- Name: student_attendance; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.student_attendance ENABLE ROW LEVEL SECURITY;

--
-- Name: TABLE student; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE ON TABLE public.student TO school_role;
GRANT SELECT ON TABLE public.student TO city_role;
GRANT SELECT ON TABLE public.student TO district_role;


--
-- Name: COLUMN student.student_name; Type: ACL; Schema: public; Owner: postgres
--

GRANT UPDATE(student_name) ON TABLE public.student TO school_role;


--
-- Name: COLUMN student.standard; Type: ACL; Schema: public; Owner: postgres
--

GRANT UPDATE(standard) ON TABLE public.student TO school_role;


--
-- Name: COLUMN student.height; Type: ACL; Schema: public; Owner: postgres
--

GRANT UPDATE(height) ON TABLE public.student TO school_role;


--
-- Name: COLUMN student.weight; Type: ACL; Schema: public; Owner: postgres
--

GRANT UPDATE(weight) ON TABLE public.student TO school_role;


--
-- Name: COLUMN student.mdm_enrollment; Type: ACL; Schema: public; Owner: postgres
--

GRANT UPDATE(mdm_enrollment) ON TABLE public.student TO school_role;


--
-- Name: TABLE city_committee; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.city_committee TO school_role;
GRANT SELECT ON TABLE public.city_committee TO city_role;


--
-- Name: TABLE grievances; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.grievances TO school_role;
GRANT SELECT ON TABLE public.grievances TO city_role;
GRANT SELECT ON TABLE public.grievances TO district_role;


--
-- Name: COLUMN grievances.status; Type: ACL; Schema: public; Owner: postgres
--

GRANT UPDATE(status) ON TABLE public.grievances TO city_role;
GRANT UPDATE(status) ON TABLE public.grievances TO district_role;


--
-- Name: COLUMN grievances.actions_taken; Type: ACL; Schema: public; Owner: postgres
--

GRANT UPDATE(actions_taken) ON TABLE public.grievances TO city_role;
GRANT UPDATE(actions_taken) ON TABLE public.grievances TO district_role;


--
-- Name: TABLE mdm_school_committee; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.mdm_school_committee TO school_role;
GRANT SELECT,INSERT ON TABLE public.mdm_school_committee TO city_role;
GRANT SELECT,INSERT ON TABLE public.mdm_school_committee TO district_role;


--
-- Name: COLUMN mdm_school_committee.manager_id; Type: ACL; Schema: public; Owner: postgres
--

GRANT UPDATE(manager_id) ON TABLE public.mdm_school_committee TO city_role;
GRANT UPDATE(manager_id) ON TABLE public.mdm_school_committee TO district_role;


--
-- Name: COLUMN mdm_school_committee.manager_name; Type: ACL; Schema: public; Owner: postgres
--

GRANT UPDATE(manager_name) ON TABLE public.mdm_school_committee TO city_role;
GRANT UPDATE(manager_name) ON TABLE public.mdm_school_committee TO district_role;


--
-- Name: COLUMN mdm_school_committee.budget; Type: ACL; Schema: public; Owner: postgres
--

GRANT UPDATE(budget) ON TABLE public.mdm_school_committee TO city_role;
GRANT UPDATE(budget) ON TABLE public.mdm_school_committee TO district_role;


--
-- Name: TABLE cook; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.cook TO school_role;
GRANT SELECT ON TABLE public.cook TO city_role;
GRANT SELECT ON TABLE public.cook TO district_role;


--
-- Name: TABLE daily_stock_usage; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.daily_stock_usage TO school_role;
GRANT SELECT ON TABLE public.daily_stock_usage TO city_role;
GRANT SELECT ON TABLE public.daily_stock_usage TO district_role;


--
-- Name: TABLE district_committee; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.district_committee TO school_role;
GRANT SELECT ON TABLE public.district_committee TO city_role;
GRANT SELECT,INSERT,UPDATE ON TABLE public.district_committee TO district_role;


--
-- Name: TABLE district_static; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.district_static TO school_role;
GRANT SELECT ON TABLE public.district_static TO city_role;
GRANT SELECT,INSERT,UPDATE ON TABLE public.district_static TO district_role;


--
-- Name: TABLE inspection_feedback; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.inspection_feedback TO school_role;
GRANT SELECT ON TABLE public.inspection_feedback TO city_role;
GRANT SELECT,INSERT ON TABLE public.inspection_feedback TO district_role;


--
-- Name: TABLE item_prices; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.item_prices TO school_role;
GRANT SELECT,INSERT,UPDATE ON TABLE public.item_prices TO city_role;
GRANT SELECT ON TABLE public.item_prices TO district_role;


--
-- Name: TABLE school; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.school TO school_role;
GRANT SELECT,INSERT ON TABLE public.school TO city_role;
GRANT SELECT,INSERT ON TABLE public.school TO district_role;


--
-- Name: COLUMN school.principal_name; Type: ACL; Schema: public; Owner: postgres
--

GRANT UPDATE(principal_name) ON TABLE public.school TO school_role;


--
-- Name: COLUMN school.contact_number; Type: ACL; Schema: public; Owner: postgres
--

GRANT UPDATE(contact_number) ON TABLE public.school TO school_role;


--
-- Name: COLUMN school.email; Type: ACL; Schema: public; Owner: postgres
--

GRANT UPDATE(email) ON TABLE public.school TO school_role;


--
-- Name: COLUMN school.mdm_enrollment; Type: ACL; Schema: public; Owner: postgres
--

GRANT UPDATE(mdm_enrollment) ON TABLE public.school TO district_role;


--
-- Name: TABLE stock_left; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.stock_left TO school_role;
GRANT SELECT ON TABLE public.stock_left TO city_role;
GRANT SELECT ON TABLE public.stock_left TO district_role;


--
-- Name: TABLE student_attendance; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.student_attendance TO school_role;
GRANT SELECT ON TABLE public.student_attendance TO city_role;
GRANT SELECT ON TABLE public.student_attendance TO district_role;


--
-- PostgreSQL database dump complete
--

